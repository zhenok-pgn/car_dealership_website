<?php
    function getLikedButt()
    {
        return "image/favoritesonhover.svg";
    }

    function getUnlikedButt()
    {
        return "image/favorites.svg";
    }