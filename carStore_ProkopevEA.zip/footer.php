<footer class="footer mt-5 py-3 bg-body-tertiary">
      <div class="container">
        <div class="row">
        <div class="col">
          <svg class="bi me-2" width="120" height="65" role="img">
            <use xlink:href="#bootstrap" />
            <image
              xlink:href="image/carlogo.png"
              x="0"
              y="0"
              height="65px"
              width="120px"
            />
          </svg>
        </div>
        <div class="col">
          <a class="nav-link text-start p-2" href="catalog.php?condition=new">Новые автомобили</a>
          <a class="nav-link text-start p-2" href="catalog.php?condition=used">Авто с пробегом</a>
        </div>
        <div class="col">
          <a class="nav-link text-start p-2" href="#">Выкуп авто</a>
          <a class="nav-link text-start p-2" href="#">Акции</a>
        </div>
        <div class="col">
          <a class="nav-link text-start p-2" href="#">Контакты</a>
        </div>
        </div>
      </div>
</footer>